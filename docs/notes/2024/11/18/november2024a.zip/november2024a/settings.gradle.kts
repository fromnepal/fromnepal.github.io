rootProject.name = "november2024a"
