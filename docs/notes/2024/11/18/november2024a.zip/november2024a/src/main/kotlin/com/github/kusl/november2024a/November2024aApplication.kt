package com.github.kusl.november2024a

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class November2024aApplication

fun main(args: Array<String>) {
	runApplication<November2024aApplication>(*args)
}
