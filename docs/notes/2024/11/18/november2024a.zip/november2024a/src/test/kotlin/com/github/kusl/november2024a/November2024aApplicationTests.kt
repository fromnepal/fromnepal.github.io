package com.github.kusl.november2024a

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class November2024aApplicationTests {

	@Test
	fun contextLoads() {
	}

}
